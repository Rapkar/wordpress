<script type="text/html" id='tmpl-wooccm-modal-main'>
  <?php require_once 'parts/main.php'; ?>
</script>
<script type="text/html" id='tmpl-wooccm-modal-tabs'>
  <?php require_once 'parts/tabs.php'; ?>
</script>
<script type="text/html" id='tmpl-wooccm-modal-panels'>
  <?php require_once 'parts/panel-general.php'; ?>
  <?php require_once 'parts/panel-select2.php'; ?>
  <?php require_once 'parts/panel-options.php'; ?>
  <?php require_once 'parts/panel-filter.php'; ?>
  <?php require_once 'parts/panel-display.php'; ?>
  <?php require_once 'parts/panel-price.php'; ?>
  <?php require_once 'parts/panel-datepicker.php'; ?>
  <?php require_once 'parts/panel-timepicker.php'; ?>
  <?php require_once 'parts/panel-admin.php'; ?>
</script>
<script type="text/html" id='tmpl-wooccm-modal-info'>
  <?php require_once 'parts/info.php'; ?>
</script>
